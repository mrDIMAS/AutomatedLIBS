
#include <windows.h>
#include <math.h>
#include <string>
#include <strstream>
#include "mex.h"
#include "avaspec.h"
#include "utility.h"

//#define _DEBUG

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// Types
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
typedef void(*Handler) (int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);

typedef struct {
	char *pCommand;
	Handler pHandler;
} CommandHandler;

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//  Forward Declarations
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
void ThrowString(char * szError);
bool ArrayToString(const mxArray *pArray, std::string &str);
int GetDoubleFieldValue(double *val, char *fieldname, const mxArray *prhs[]);
int GetStringFieldValue(char *val, char *fieldname, const mxArray *prhs[]);
void CommandDispatch(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnGetNumPixels(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnGetLambda(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnGetVersion(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnSetDigOut(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnSetPwmOut(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnSetAnalogOut(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnMeasureConfig(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnMeasure(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnStopMeasure(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnGetData(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnGetSaturated(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnDataReady(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnGetParameter(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnSetParameter(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnUseHighRes(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnSetSyncMode(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnSetPrescanMode(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnGetDigIn(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnGetAnalogIn(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnSetSensitivityMode(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnInit(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnDone(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnGetList(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnActivate(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void OnDeactivate(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);

// ------------------------
// Globals
// ------------------------

bool bFirstTime = true;

CommandHandler commands[] = {
		"getnumpixels", OnGetNumPixels,
		"getlambda", OnGetLambda,
		"getversion", OnGetVersion,
		"setdigout", OnSetDigOut,
		"setpwmout", OnSetPwmOut,
		"setanalogout", OnSetAnalogOut,
		"measconfig", OnMeasureConfig,
		"measure", OnMeasure,
		"stop", OnStopMeasure,
		"getdata", OnGetData,
		"getsaturated", OnGetSaturated,
		"ready", OnDataReady,
		"getparameter", OnGetParameter,
		"setparameter", OnSetParameter,
		"usehighres", OnUseHighRes,
		"setsyncmode", OnSetSyncMode,
		"setprescanmode", OnSetPrescanMode,
		"getdigin", OnGetDigIn,
		"getanalogin", OnGetAnalogIn,
		"setsensitivitymode", OnSetSensitivityMode,
		"init", OnInit,
		"done", OnDone,
		"getlist", OnGetList,
		"activate", OnActivate,
		"deactivate", OnDeactivate
};

void DebugStringMessage(char * msg)
{
#ifdef _DEBUG
	mexPrintf("AS5216 debug message: %s\n", msg);
#endif
}

void DebugIntegerMessage(int intval)
{
#ifdef _DEBUG
	mexPrintf("AS5216 debug message: %d\n", intval);
#endif
}

void ErrorMessage(char * msg)
{
	mexPrintf("AS5216 ERROR message: %s\n", msg);
}

void CheckRet(int retval)
{
	switch(retval)
	{
	case 0:
		//		return;  Do Nothing
		break;
	case -1:
		ErrorMessage("Invalid parameter");
		break;
	case -2:
		ErrorMessage("Operation not supported");
		break;
	case -3:
		ErrorMessage("Device not found");
		break;
	case -4:
		ErrorMessage("Invalid device ID");
		break;
	case -5:
		ErrorMessage("Operation pending");
		break;
	case -6:
		ErrorMessage("Timeout");
		break;
	case -7:
		ErrorMessage("Invalid password");
		break;
	case -8:
		ErrorMessage("Invalid measurement data");
		break;	
	case -9:
		ErrorMessage("Invalid size");
		break;
	case -10:
		ErrorMessage("Invalid pixel range");
		break;	
	case -11:
		ErrorMessage("Invalid integration time");
		break;	
	case -12:
		ErrorMessage("Invalid combination");
		break;	
	case -13:
		ErrorMessage("Invalid configuration");
		break;
	case -14:
		ErrorMessage("No measurement buffer available");
		break;
	case -15:
		ErrorMessage("Unknown error");
		break;
	case -16:
		ErrorMessage("Communication error");
		break;
	case -17:
		ErrorMessage("No spectra in RAM");
		break;
	case -18:
		ErrorMessage("Invalid DLL version");
		break;
	case -19:
		ErrorMessage("No memory");
		break;
	case -20:
		ErrorMessage("DLL initialisation failed");
		break;
	case -21:
		ErrorMessage("Invalid state");
		break;
	}
}

static void ExitFunction(void)
{
	DebugStringMessage("Closing communication");
	CheckRet(AVS_Done());
}

bool ArrayToString(const mxArray *pArray, std::string &str)
{
	bool okay = true;
	int buflen;
	int status;
	
	if (mxIsChar(pArray) != 1) {
		str = "vfm: requires a string";
		okay = false;
	}
	
	buflen = mxGetN(pArray) + 1;
	char *pStr = (char*)mxCalloc (buflen, sizeof(char));
	status = mxGetString (pArray, pStr, buflen);
	if (status != 0)
		mexWarnMsgTxt ("Not enough space. String truncated.");
	
	str = pStr;
	mxFree(pStr);
	return okay;
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	if (bFirstTime)
	{
		mexAtExit(ExitFunction);
		bFirstTime = false;
	}
	
	if (nrhs == 0)
		return;
	
	try
	{
		CommandDispatch(nlhs, plhs, nrhs, prhs);
	}
	catch (std::string *pStr)
	{
		mexWarnMsgTxt(pStr->c_str());
		delete_ptr (pStr);
	}
	
	return;
}

void CommandDispatch(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	std::string str;
	
	if (!ArrayToString (prhs[0], str)) {
		mexWarnMsgTxt(str.c_str());
		return;
	}
	if (nlhs == 0) nlhs++;
	WORD wItems = sizeof (commands) / sizeof(CommandHandler);
	bool bFound = false;
	
	for (WORD wIndex = 0; wIndex < wItems && !bFound; wIndex++)
	{
		if (str == commands[wIndex].pCommand) {
			bFound = true;
			commands[wIndex].pHandler(nlhs, plhs, nrhs-1, prhs+1);
		}
	}
	
	std::ostrstream error;
	
	if (!bFound) {
		error << "Unrecognised command: " << str.data() << std::ends;
		ThrowString (error.str());
	}
}

inline void ThrowString(char * szError)
{
	std::string *pError = new std::string (szError);
	throw (pError);
}

void OnGetNumPixels(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	unsigned short numpixels;
	unsigned short *np;
	const int dims[] = {1, 1};

	DebugStringMessage("OnGetNumPixels");
	// error checking for arguments
	if (nrhs != 1) {
		ThrowString("wrong # of arguments - should be 'getnumpixels', handle ");
	}
	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	plhs[0] = mxCreateNumericArray(2, dims, mxUINT16_CLASS, mxREAL);
	np = (unsigned short*) mxGetData(plhs[0]);
	CheckRet(AVS_GetNumPixels(hDevice, &numpixels));
	*np = numpixels;
}

void OnGetLambda(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	unsigned short numpixels;
	double * lambda;
	
	DebugStringMessage("OnGetLambda");
	// error checking for arguments
	if (nrhs != 1) {
		ThrowString ("wrong # of arguments - should be 'getlambda', handle ");
	}
	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	CheckRet(AVS_GetNumPixels(hDevice, &numpixels));
	plhs[0] = mxCreateDoubleMatrix(numpixels, 1, mxREAL);
	lambda = mxGetPr(plhs[0]);
	CheckRet(AVS_GetLambda(hDevice, lambda));
}

void OnGetVersion(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	char fpga[16];
	char firmware[16];
	char dll[16];
	int dims[2] = {1, 1};
	const char *field_names[] = {"fpga", "firmware", "dll"};
	
	DebugStringMessage("OnGetVersionInfo");
	// error checking for arguments
	if (nrhs != 1) {
		ThrowString ("wrong # of arguments - should be 'getversioninfo', handle ");
	}
	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	CheckRet(AVS_GetVersionInfo(hDevice, fpga, firmware, dll));
	
	DebugStringMessage(fpga);
	DebugStringMessage(firmware);
	DebugStringMessage(dll);
	
	plhs[0] = mxCreateStructArray(2, dims, 3, field_names);
	mxSetFieldByNumber(plhs[0], 0, 0, mxCreateString(fpga));
	mxSetFieldByNumber(plhs[0], 0, 1, mxCreateString(firmware));
	mxSetFieldByNumber(plhs[0], 0, 2, mxCreateString(dll));
}

void OnSetDigOut(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	unsigned char port;
	unsigned char value;
	char msg[256];
	DebugStringMessage("OnSetDigOut");
	// error checking for arguments
	if (nrhs != 3) 
		ThrowString ("wrong # of arguments - should be 'setdigout', handle, port, value ");
	
	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	port=(unsigned char) mxGetScalar(prhs[1]);
	value=(unsigned char) mxGetScalar(prhs[2]);
	
	sprintf(msg, "handle: %d, port: %d, value: %d", hDevice, port, value);
	DebugStringMessage(msg);
	
	CheckRet(AVS_SetDigOut(hDevice, port, value));
}

void OnSetPwmOut(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	unsigned char port;
	unsigned long frequency;
	unsigned char duty;
	char msg[256];
	
	DebugStringMessage("OnSetPwmOut");
	// error checking for arguments
	if (nrhs != 4) 
		ThrowString ("wrong # of arguments - should be 'setpwmout', handle, port, frequency, dutycycle ");
	
	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	port=(unsigned char) mxGetScalar(prhs[1]);
	frequency=(unsigned char) mxGetScalar(prhs[2]);
	duty=(unsigned char) mxGetScalar(prhs[3]);
	
	sprintf(msg, "handle: %d, port: %d, frequency: %d, duty: %d", hDevice, port, frequency, duty);
	DebugStringMessage(msg);
	
	CheckRet(AVS_SetPwmOut(hDevice, port, frequency, duty));
}

void OnSetAnalogOut(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	unsigned char port;
	float voltage;
	
	DebugStringMessage("OnSetAnalogOut");
	// error checking for arguments
	if (nrhs != 3) 
		ThrowString ("wrong # of arguments - should be 'setanalogout', handle, port, voltage ");
	
	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	port=(unsigned char) mxGetScalar(prhs[1]);
	voltage=(float) mxGetScalar(prhs[2]);
	
	CheckRet(AVS_SetAnalogOut(hDevice, port, voltage));
}

void OnMeasureConfig(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	MeasConfigType config;
	AvsHandle hDevice;
	unsigned short numpixels;
	double val;
	DarkCorrectionType darkcorrection;
	SmoothingType smoothing;
	TriggerType trigger;
	ControlSettingsType controlsettings;
	
	// Set default values
	config.m_StartPixel=0;
	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	CheckRet(AVS_GetNumPixels(hDevice, &numpixels));
	config.m_StopPixel=numpixels-1;
	config.m_IntegrationTime=500;
	config.m_IntegrationDelay=0;
	config.m_NrAverages=1;
	darkcorrection.m_Enable=1;
	darkcorrection.m_ForgetPercentage=100;
	
	smoothing.m_SmoothModel=0;
	smoothing.m_SmoothPix=2;
	config.m_Smoothing=smoothing;
	config.m_SaturationDetection=1;
	trigger.m_Mode=0;
	trigger.m_Source=0;
	trigger.m_SourceType=0;
	controlsettings.m_StrobeControl=0;
	controlsettings.m_LaserDelay=0;
	controlsettings.m_LaserWidth=0;
	controlsettings.m_LaserWaveLength=0;
	controlsettings.m_StoreToRam=0;
	
	DebugStringMessage("OnMeasureConfig");
	if (nrhs != 2) 
		ThrowString ("wrong # of arguments - should be 'measconfig' handle, settings ");
	
	// Check for settings
	if (nrhs==2)
	{
		if (GetDoubleFieldValue(&val, "IntegrationTime", prhs)) 
			config.m_IntegrationTime=(float) val;
		if (GetDoubleFieldValue(&val, "StartPixel", prhs))
			config.m_StartPixel=(uint16) val;
		if (GetDoubleFieldValue(&val, "StopPixel", prhs)) 
			config.m_StopPixel=(uint16) val;
		if (GetDoubleFieldValue(&val, "IntegrationDelay", prhs)) 
			config.m_IntegrationDelay=(uint32) val;
		if (GetDoubleFieldValue(&val, "NrAverages", prhs)) 
			config.m_NrAverages=(uint32) val;
		if (GetDoubleFieldValue(&val, "CorDynDark", prhs)) 
			darkcorrection.m_Enable=(uint8) val;
		if (GetDoubleFieldValue(&val, "Smoothing", prhs)) 
			smoothing.m_SmoothPix=(uint16) val;
		if (GetDoubleFieldValue(&val, "TriggerMode", prhs)) 
			trigger.m_Mode=(uint8) val;
		if (GetDoubleFieldValue(&val, "TriggerSource", prhs)) 
			trigger.m_Source=(uint8) val;
		if (GetDoubleFieldValue(&val, "TriggerSourceType", prhs)) 
			trigger.m_SourceType=(uint8) val;
		if (GetDoubleFieldValue(&val, "SaturationDetection", prhs)) 
			config.m_SaturationDetection=(uint8) val;
		if (GetDoubleFieldValue(&val, "NrStoreToRam", prhs))
			controlsettings.m_StoreToRam=(uint16) val;
	}
	
#ifdef _DEBUG
	mexPrintf("NrAverages: %i\n", config.m_NrAverages);
#endif
	
	config.m_CorDynDark=darkcorrection;
	config.m_Smoothing=smoothing;
	config.m_Trigger=trigger;
	config.m_Control=controlsettings;
	
	DebugStringMessage("OnMeasureConfig");
	
	CheckRet(AVS_PrepareMeasure(hDevice, &config));
}

int GetDoubleFieldValue(double *val, char *fieldname, const mxArray *prhs[])
{
	mxArray * tmp;
	
	if (!mxIsStruct(prhs[1]))
		ErrorMessage("settings must be a struct");
	tmp = mxGetField(prhs[1], 0, fieldname);
	if (tmp == NULL)
	{
#ifdef _DEBUG
		mexPrintf("GetDoubleFieldValue: Empty field, %s\n", fieldname);
#endif
		return(0);
	}
	else
	{
		if (!mxIsNumeric(tmp))
			mexErrMsgTxt("Non-numeric field\n");
		*val = mxGetScalar(tmp);
#ifdef _DEBUG
		mexPrintf("GetDoubleFieldValue: %s: %4.3f\n", fieldname, *val);
#endif
		return(1);
	}
}

int GetStringFieldValue(char *val, char *fieldname, const mxArray *prhs[])
{
	mxArray * tmp;
	
	if (!mxIsStruct(prhs[1]))
		ErrorMessage("settings must be a struct");
	tmp = mxGetField(prhs[1], 0, fieldname);
	if (tmp == NULL)
	{
#ifdef _DEBUG
		mexPrintf("GetStringFieldValue: Empty field, %s\n", fieldname);
#endif
		return(0);
	}
	else
	{
		if (!mxIsChar(tmp))
			mexErrMsgTxt("Non-string field\n");
		mxGetString(tmp, val, 64);
#ifdef _DEBUG
		mexPrintf("GetStringFieldValue: %s: %s\n", fieldname, val);
#endif
		return(1);
	}
}

void OnMeasure(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	short number=1;
	
	if (nrhs > 2) 
		ThrowString ("wrong # of arguments - should be 'measure' handle, number");
	
	if (nrhs == 2)
	{
		hDevice = (AvsHandle) mxGetScalar(prhs[0]);
		number = (short) mxGetScalar(prhs[1]);
	}
	
	DebugStringMessage("OnMeasure");
	CheckRet(AVS_Measure(hDevice, NULL, number));
}

void OnStopMeasure(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;

	if (nrhs != 1) 
		ThrowString ("wrong # of arguments - should be 'stop', handle");
	
	DebugStringMessage("OnStopMeasure");
	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	CheckRet(AVS_StopMeasure(hDevice));
}

void OnGetData(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	unsigned short numpixels;
	unsigned int timelabel;
	double * data;

	DebugStringMessage("OnGetData");
	if (nrhs != 1) 
		ThrowString ("wrong # of arguments - should be 'getdata', handle ");

	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	CheckRet(AVS_GetNumPixels(hDevice, &numpixels));
	plhs[0] = mxCreateDoubleMatrix(numpixels, 1, mxREAL);
	data = mxGetPr(plhs[0]);
	CheckRet(AVS_GetScopeData(hDevice, &timelabel, data));
}

void OnGetSaturated(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	unsigned short numpixels;
	int dims[2];
	unsigned char * sat;

	DebugStringMessage("OnGetSaturated");
	if (nrhs != 1) 
		ThrowString ("wrong # of arguments - should be 'getsaturated', handle ");

	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	CheckRet(AVS_GetNumPixels(hDevice, &numpixels));
	dims[0] = 1;
	dims[1] = numpixels;
	plhs[0] = mxCreateNumericArray(2, dims, mxUINT8_CLASS, mxREAL);
	sat = (unsigned char*) mxGetData(plhs[0]);
	CheckRet(AVS_GetSaturatedPixels(hDevice, sat));
}

void OnDataReady(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	int ready;
	double * d;
	
	DebugStringMessage("OnDataReady");
	if (nrhs != 1) 
		ThrowString ("wrong # of arguments - should be 'ready', handle ");
	
	plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	ready = AVS_PollScan(hDevice);
	if (ready < 0)	// Error encountered
		CheckRet(ready);
	
	d = mxGetPr(plhs[0]);
	*d = ready;
}

void OnGetParameter(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	DeviceConfigType devcon;
	AvsHandle hDevice;
	unsigned int l_Size;
	int dims[2]={1, 1};
	const char *field_names[] = {"FriendlyName", "SensorType"};
	mxArray *fout;
	char friendly[64];
	unsigned char sensortype;
	unsigned char *st;

    hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	CheckRet(AVS_GetParameter(hDevice, sizeof(devcon), &l_Size, &devcon));
	plhs[0] = mxCreateStructArray(2, dims, 2, field_names); 
	strcpy(friendly,devcon.m_aUserFriendlyId);
	sensortype=devcon.m_Detector.m_SensorType;
	DebugStringMessage(friendly);
	DebugIntegerMessage(sensortype);

	mxSetFieldByNumber(plhs[0], 0, 0, mxCreateString(friendly));

	fout=mxCreateNumericArray(2, dims, mxUINT8_CLASS, mxREAL);
	st=(unsigned char*) mxGetData(fout);
	*st=sensortype;
	mxSetFieldByNumber(plhs[0], 0, 1, fout);
}

void OnSetParameter(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	DeviceConfigType devcon;
	AvsHandle hDevice;
	unsigned int l_Size;
	char friendly[64];

	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
    CheckRet(AVS_GetParameter(hDevice, sizeof(devcon), &l_Size, &devcon));
	if (nrhs==2)
	{
		if (GetStringFieldValue(&friendly[0], "FriendlyName", prhs)) 
			strcpy(devcon.m_aUserFriendlyId,friendly);
		DebugStringMessage(friendly);
		CheckRet(AVS_SetParameter(hDevice, &devcon));
	}
}

void OnUseHighRes(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	bool enable;

	DebugStringMessage("OnUseHighRes");
	if (nrhs != 2)
		ThrowString ("wrong # of arguments - should be 'usehighres', handle, true(1) or false(0)");

	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	enable = (mxGetScalar(prhs[1]) != 0);
	CheckRet(AVS_UseHighResAdc(hDevice, enable));
}

void OnSetSyncMode(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	bool enable;

	DebugStringMessage("OnSetSyncMode");
	if (nrhs != 2)
		ThrowString ("wrong # of arguments - should be 'setsyncmode', handle, true(1) or false(0)");

	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	enable = (mxGetScalar(prhs[1]) != 0);
	CheckRet(AVS_SetSyncMode(hDevice, enable));
}

void OnSetPrescanMode(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	bool enable;

	DebugStringMessage("OnSetPrescanMode");
	if (nrhs != 2)
		ThrowString ("wrong # of arguments - should be 'setprescanmode', handle, true(1) or false(0)");

	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	enable = (mxGetScalar(prhs[1]) != 0);
	CheckRet(AVS_SetPrescanMode(hDevice, enable));
}

void OnGetDigIn(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	unsigned char digin;
	unsigned char status;
	unsigned char *stat;
	const int dims[] = {1, 1};

	DebugStringMessage("OnGetDigIn");
	if (nrhs != 2)
		ThrowString ("wrong # of arguments - should be 'getdigin', handle, DI# (0..2)");

	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	digin = (unsigned char) mxGetScalar(prhs[1]);
	CheckRet(AVS_GetDigIn(hDevice, digin, &status));

	plhs[0] = mxCreateNumericArray(2, dims, mxUINT8_CLASS, mxREAL);
	stat = (unsigned char*) mxGetData(plhs[0]);
	*stat = status;
}

void OnGetAnalogIn(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	unsigned char analogin;
	float value;
	float *val;
	const int dims[] = {1, 1};

	DebugStringMessage("OnGetAnalogIn");
	if (nrhs != 2)
		ThrowString ("wrong # of arguments - should be 'getanalogin', handle, AI# (0..7)");

	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	analogin = (unsigned char) mxGetScalar(prhs[1]);
	CheckRet(AVS_GetAnalogIn(hDevice, analogin, &value));

	plhs[0] = mxCreateNumericArray(2, dims, mxSINGLE_CLASS, mxREAL);
	val = (float*) mxGetData(plhs[0]);
	*val = value;
}

void OnSetSensitivityMode(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	unsigned int a_SensitivityMode;
	char msg[256];

	DebugStringMessage("OnSetSensitivityMode");
	// error checking for arguments
	if (nrhs != 2) 
		ThrowString ("wrong # of arguments - should be 'setsensitivitymode', handle, true(1) or false(0) ");
	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	a_SensitivityMode=(unsigned int) mxGetScalar(prhs[1]);

	sprintf(msg, "sensitivitymode: %d", a_SensitivityMode);
	DebugStringMessage(msg);
	
	CheckRet(AVS_SetSensitivityMode(hDevice, a_SensitivityMode));
}

void OnInit(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	short a_Port;
	int portnum;
	int *pn;
	const int dims[] = {1, 1};

	DebugStringMessage("Init");
	if (nrhs != 1 )
		ThrowString ("wrong # of arguments - should be 'init' port ");
	
	a_Port = (short) mxGetScalar(prhs[0]);
	plhs[0] = mxCreateNumericArray(2, dims, mxINT32_CLASS, mxREAL);
	pn = (int*) mxGetData(plhs[0]);
	portnum = AVS_Init(a_Port);
	*pn = portnum;
}

void OnDone(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	DebugStringMessage("Done");
	if (nrhs > 0 )
		ThrowString ("wrong # of arguments - should be 'done' ");
	CheckRet(AVS_Done());
}

void OnGetList(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	unsigned int l_Size = 0;
	unsigned int l_RequiredSize = 0;
	int l_NrDevices;
	char* l_pData = NULL;
	AvsIdentityType* l_pId; 

	DebugStringMessage("GetList");
	if (nrhs > 0 )
		ThrowString ("wrong # of arguments - should be 'getlist' ");
	l_NrDevices = AVS_GetNrOfDevices();
	l_RequiredSize = l_NrDevices * sizeof(AvsIdentityType);
	delete [] l_pData;
	l_pData = new char[l_RequiredSize];
	l_pId = (AvsIdentityType*)l_pData;
    l_Size = l_RequiredSize;
	l_NrDevices = AVS_GetList(l_Size, &l_RequiredSize, l_pId);

	int dims[2] = {1, l_NrDevices};
	const char *field_names[] = {"SerialNumber", "UserFriendlyName", "Status"};
	plhs[0] = mxCreateStructArray(2, dims, 3, field_names);
	for (int i = 0; i < l_NrDevices; i++)
	{
		mxSetFieldByNumber(plhs[0],i,0,mxCreateString(l_pId[i].SerialNumber));
		mxSetFieldByNumber(plhs[0],i,1,mxCreateString(l_pId[i].UserFriendlyName));
		mxArray *field_value;
		field_value = mxCreateDoubleMatrix(1,1,mxREAL);
		*mxGetPr(field_value) = l_pId[i].Status;
		mxSetFieldByNumber(plhs[0],i,2,field_value);
	}
	delete [] l_pData;
}

void OnActivate(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsIdentityType l_Active;
	if (!mxIsStruct(prhs[0]))
		ErrorMessage("identity must be a struct");
	mxArray* tmp;
	tmp = mxGetField(prhs[0], 0, "SerialNumber");
	mxGetString(tmp, l_Active.SerialNumber, 10);
	tmp = mxGetField(prhs[0], 0, "UserFriendlyName");
	mxGetString(tmp, l_Active.UserFriendlyName, 64);
	tmp = mxGetField(prhs[0], 0, "Status");
	l_Active.Status = (unsigned char) mxGetScalar(tmp);

	AvsHandle l_hDevice ;
	AvsHandle* phandle;
	const int dims[] = {1, 1};

	plhs[0] = mxCreateNumericArray(2, dims, mxINT32_CLASS, mxREAL);
	phandle = (AvsHandle*) mxGetData(plhs[0]);
	l_hDevice = AVS_Activate(&l_Active);
	*phandle = l_hDevice;
}

void OnDeactivate(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	AvsHandle hDevice;
	DebugStringMessage("Deactivate");
	if (nrhs != 1 )
		ThrowString ("wrong # of arguments - should be 'deactivate', handle ");
	hDevice = (AvsHandle) mxGetScalar(prhs[0]);
	CheckRet(AVS_Deactivate(hDevice));
}