function varargout = test_storetoram(varargin)
% TEST_STORETORAM M-file for test_storetoram.fig
%      TEST_STORETORAM, by itself, creates a new TEST_STORETORAM or raises the existing
%      singleton*.
%
%      H = TEST_STORETORAM returns the handle to a new TEST_STORETORAM or the handle to
%      the existing singleton*.
%
%      TEST_STORETORAM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TEST_STORETORAM.M with the given input arguments.
%
%      TEST_STORETORAM('Property','Value',...) creates a new TEST_STORETORAM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before test_storetoram_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to test_storetoram_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help test_storetoram

% Last Modified by GUIDE v2.5 15-Oct-2013 16:03:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @test_storetoram_OpeningFcn, ...
                   'gui_OutputFcn',  @test_storetoram_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before test_storetoram is made visible.
function test_storetoram_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to test_storetoram (see VARARGIN)

% Choose default command line output for test_storetoram
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
xlabel('Wavelength [nm]')
ylabel('Counts')

% UIWAIT makes test_storetoram wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = test_storetoram_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in OpenCommBtn.
function OpenCommBtn_Callback(hObject, eventdata, handles)
% hObject    handle to OpenCommBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global hDevice1 hDevice2
nport=spectrometer('init',0);
ID=spectrometer('getlist');
hDevice1=spectrometer('activate',ID(1));
hDevice2=spectrometer('activate',ID(2));
global P1 P2
P1=spectrometer('getparameter',hDevice1);
P2=spectrometer('getparameter',hDevice2);
ver=spectrometer('getversion',hDevice1);
nPix1=spectrometer('getnumpixels',hDevice1);
nPix2=spectrometer('getnumpixels',hDevice2);
ver=spectrometer('getversion',hDevice1);
msgbox(sprintf('Friendly name: %s\nSensortype: %d\nNumber of pixels: %d\nDll version: %s',P1.FriendlyName,P1.SensorType,nPix1,ver.dll), 'Spectrometer 1');
msgbox(sprintf('Friendly name: %s\nSensortype: %d\nNumber of pixels: %d\nDll version: %s',P2.FriendlyName,P2.SensorType,nPix2,ver.dll), 'Spectrometer 2');
global S1 S2
S1.IntegrationTime=5.0;
S1.StartPixel=0;
S1.StopPixel=nPix1-1;
S1.IntegrationDelay=0;
S1.NrAverages=1;
S1.CorDynDark=0;
S1.Smoothing=0;
S1.TriggerMode=1;
S1.TriggerSource=0;
S1.TriggerSourceType=0;
S1.SaturationDetection=1;
S1.NrStoreToRam=1;
    
S2.IntegrationTime=5.0;
S2.StartPixel=0;
S2.StopPixel=nPix2-1;
S2.IntegrationDelay=0;
S2.NrAverages=1;
S2.CorDynDark=0;
S2.Smoothing=0;
S2.TriggerMode=1;
S2.TriggerSource=0;
S2.TriggerSourceType=0;
S2.SaturationDetection=1;
S2.NrStoreToRam=1;

% --- Executes on button press in CloseCommBtn.
function CloseCommBtn_Callback(hObject, eventdata, handles)
% hObject    handle to CloseCommBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global hDevice1 hDevice2
spectrometer('deactivate',hDevice1);
spectrometer('deactivate',hDevice2);
spectrometer('done');

% --- Executes on button press in StartMeasBtn.
function StartMeasBtn_Callback(hObject, eventdata, handles)
% hObject    handle to StartMeasBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global stoploop
global Measnum
global hDevice1 hDevice2
global S1 S2
nPix1=spectrometer('getnumpixels',hDevice1);
nPix2=spectrometer('getnumpixels',hDevice2);
spectrometer('usehighres',hDevice1,true);
spectrometer('usehighres',hDevice2,true);
stoploop=false;
NrMeas=0;
while (stoploop==false) && (NrMeas<Measnum)
    myLambda1=spectrometer('getlambda',hDevice1);
    myLambda2=spectrometer('getlambda',hDevice2);
    spectrometer('measconfig',hDevice1,S1);
    spectrometer('measconfig',hDevice2,S2);
    spectrometer('measure',hDevice1,1);
    spectrometer('measure',hDevice2,1);
    ready1=false;
    ready2=false;
    while ((ready1==false) || (ready2==false))
        if ready1==false
            ready1=spectrometer('ready',hDevice1);
        end
        if ready2==false
            ready2=spectrometer('ready',hDevice2);
        end
        pause(0.001); %seconds !!
    end
    NrSTR=0;
    while (NrSTR<S1.NrStoreToRam) && (NrSTR<1013)  % max 1013 scans of 2048 pixels
        myData1=spectrometer('getdata',hDevice1);
        myData2=spectrometer('getdata',hDevice2);
        % sat1=spectrometer('getsaturated',hDevice1);
        % sat2=spectrometer('getsaturated',hDevice2);
        plot(myLambda1,myData1,myLambda2,myData2);
        axis manual;
        axis([min(myLambda1(1),myLambda2(1)) max(myLambda1(nPix1),myLambda2(nPix2)) 0 70000]);
        xlabel('Wavelength [nm]');
        ylabel('Counts');
        pause(0.001)  %seconds !!
        NrSTR=NrSTR+1;
    end    
    NrMeas=NrMeas+1;
end

% --- Executes on button press in StopMeasBtn.
function StopMeasBtn_Callback(hObject, eventdata, handles)
% hObject    handle to StopMeasBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global stoploop
stoploop=true;

function IntTimeEdt_Callback(hObject, eventdata, handles)
% hObject    handle to IntTimeEdt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of IntTimeEdt as text
%        str2double(get(hObject,'String')) returns contents of IntTimeEdt as a double

inttimestring=strrep(get(hObject,'String'),',','.');  %replace all decimal commas with points
set(hObject,'String',inttimestring)
global S1 S2
S1.IntegrationTime=str2double(inttimestring);
S2.IntegrationTime=str2double(inttimestring);

% --- Executes during object creation, after setting all properties.
function IntTimeEdt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IntTimeEdt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

set(hObject,'String','5.0');
global S1 S2
S1.IntegrationTime=5.0;
S2.IntegrationTime=5.0;

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function StrNumEdt_Callback(hObject, eventdata, handles)
% hObject    handle to StrNumEdt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of StrNumEdt as text
%        str2double(get(hObject,'String')) returns contents of StrNumEdt as a double
global S1 S2
S1.NrStoreToRam=str2num(get(hObject,'String'));
S2.NrStoreToRam=str2num(get(hObject,'String'));

% --- Executes during object creation, after setting all properties.
function StrNumEdt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to StrNumEdt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

set(hObject,'String','1');
global S1 S2
S1.NrStoreToRam=1;
S2.NrStoreToRam=1;

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function MeasnumEdt_Callback(hObject, eventdata, handles)
% hObject    handle to MeasnumEdt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MeasnumEdt as text
%        str2double(get(hObject,'String')) returns contents of MeasnumEdt as a double

global Measnum
Measnum=str2num(get(hObject,'String'));

% --- Executes during object creation, after setting all properties.
function MeasnumEdt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MeasnumEdt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

set(hObject,'String','1');
global Measnum
Measnum=1;

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


