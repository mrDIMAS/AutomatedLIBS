function varargout = test(varargin)
% TEST M-file for test.fig
%      TEST, by itself, creates a new TEST or raises the existing
%      singleton*.
%
%      H = TEST returns the handle to a new TEST or the handle to
%      the existing singleton*.
%
%      TEST('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TEST.M with the given input arguments.
%
%      TEST('Property','Value',...) creates a new TEST or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before test_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property
%      application
%      stop.  All inputs are passed to test_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help test

% Last Modified by GUIDE v2.5 08-Apr-2013 13:20:57

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @test_OpeningFcn, ...
                   'gui_OutputFcn',  @test_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before test is made visible.
function test_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to test (see VARARGIN)

% Choose default command line output for test
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

xlabel('Wavelength [nm]')
ylabel('Counts')

% UIWAIT makes test wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = test_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in OpenComm.
function OpenComm_Callback(hObject, eventdata, handles)
% hObject    handle to OpenComm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global hDevice1 hDevice2
nport=spectrometer('init',0);
ID=spectrometer('getlist');
hDevice1=spectrometer('activate',ID(1));
hDevice2=spectrometer('activate',ID(2));
global P1 P2
P1=spectrometer('getparameter',hDevice1);
P2=spectrometer('getparameter',hDevice2);
ver=spectrometer('getversion',hDevice1);
nPix1=spectrometer('getnumpixels',hDevice1);
nPix2=spectrometer('getnumpixels',hDevice2);
ver=spectrometer('getversion',hDevice1);
msgbox(sprintf('Friendly name: %s\nSensortype: %d\nNumber of pixels: %d\nDll version: %s',P1.FriendlyName,P1.SensorType,nPix1,ver.dll), 'Spectrometer 1');
msgbox(sprintf('Friendly name: %s\nSensortype: %d\nNumber of pixels: %d\nDll version: %s',P2.FriendlyName,P2.SensorType,nPix2,ver.dll), 'Spectrometer 2');

% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)
% hObject    handle to FileMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to OpenMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file = uigetfile('*.fig');
if ~isequal(file, 0)
    open(file);
end

% --------------------------------------------------------------------
function PrintMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to PrintMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg(handles.figure1)

% --------------------------------------------------------------------
function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.figure1,'Name') '?'],...
                     ['Close ' get(handles.figure1,'Name') '...'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end
delete(handles.figure1)

function MeasnumEdt_Callback(hObject, eventdata, handles)
% hObject    handle to MeasnumEdt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MeasnumEdt as text
%        str2double(get(hObject,'String')) returns contents of MeasnumEdt as a double
global Measnum
Measnum=str2num(get(hObject,'String'));

% --- Executes during object creation, after setting all properties.
function MeasnumEdt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MeasnumEdt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
set(hObject,'String','1');
global Measnum
Measnum=1;

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in AnalogInDemo.
function AnalogInDemo_Callback(hObject, eventdata, handles)
% hObject    handle to AnalogInDemo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global hDevice1
analog=spectrometer('getanalogin',hDevice1,3);
msgbox(sprintf('Analog Input #3 (USB voltage): %5.3f V',analog))

% --- Executes on button press in StartMeas.
function StartMeas_Callback(hObject, eventdata, handles)
% hObject    handle to StartMeas (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global stoploop
global S1 S2
global Measnum
global hDevice1 hDevice2
nPix1=spectrometer('getnumpixels',hDevice1);
nPix2=spectrometer('getnumpixels',hDevice2);
spectrometer('usehighres',hDevice1,true);
spectrometer('usehighres',hDevice2,true);
stoploop=false;
NrMeas=0;
while (stoploop==false) && (NrMeas<Measnum)
    S1.StartPixel=0;
    S1.StopPixel=nPix1-1;
    S1.IntegrationDelay=0;
    S1.CorDynDark=0;
    S1.Smoothing=0;
    S1.TriggerMode=0;
    S1.TriggerSource=0;
    S1.TriggerSourceType=0;
    S1.SaturationDetection=1;
    S1.NrStoreToRam=0;
    S2.StartPixel=0;
    S2.StopPixel=nPix2-1;
    S2.IntegrationDelay=0;
    S2.CorDynDark=0;
    S2.Smoothing=0;
    S2.TriggerMode=0;
    S2.TriggerSource=0;
    S2.TriggerSourceType=0;
    S2.SaturationDetection=1;
    S2.NrStoreToRam=0;
    myLambda1=spectrometer('getlambda',hDevice1);
    myLambda2=spectrometer('getlambda',hDevice2);
    spectrometer('measconfig',hDevice1,S1);
    spectrometer('measconfig',hDevice2,S2);
    spectrometer('measure',hDevice1,1);
    spectrometer('measure',hDevice2,1);
    ready1=false;
    ready2=false;
    while ((ready1==false) || (ready2==false))
        if ready1==false
            ready1=spectrometer('ready',hDevice1);
        end
        if ready2==false
            ready2=spectrometer('ready',hDevice2);
        end
        pause(0.001); %seconds !!
    end  
    myData1=spectrometer('getdata',hDevice1);
    myData2=spectrometer('getdata',hDevice2);
    % sat1=spectrometer('getsaturated',hDevice1);
    % sat2=spectrometer('getsaturated',hDevice2);
    plot(myLambda1,myData1,myLambda2,myData2);
    axis manual;
    axis([min(myLambda1(1),myLambda2(1)) max(myLambda1(nPix1),myLambda2(nPix2)) 0 70000]);
    NrMeas=NrMeas+1;
    xlabel('Wavelength [nm]');
    ylabel('Counts');
    pause(0.001)  %seconds !!
end

% --- Executes on button press in StopMeas.
function StopMeas_Callback(hObject, eventdata, handles)
% hObject    handle to StopMeas (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global stoploop
stoploop=true;

function AverageEdt1_Callback(hObject, eventdata, handles)
% hObject    handle to AverageEdt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of AverageEdt1 as text
%        str2double(get(hObject,'String')) returns contents of AverageEdt1 as a double
global S1
S1.NrAverages=str2num(get(hObject,'String'));

% --- Executes during object creation, after setting all properties.
function AverageEdt1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to AverageEdt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
global S1
set(hObject,'String','1');
S1.NrAverages=1;

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function IntTimeEdt1_Callback(hObject, eventdata, handles)
% hObject    handle to IntTimeEdt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of IntTimeEdt1 as text
%        str2double(get(hObject,'String')) returns contents of IntTimeEdt1 as a double
global S1
inttimestring=strrep(get(hObject,'String'),',','.');  %replace all decimal commas with points
set(hObject,'String',inttimestring)
S1.IntegrationTime=str2double(inttimestring);

% --- Executes during object creation, after setting all properties.
function IntTimeEdt1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IntTimeEdt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
global S1
set(hObject,'String','5.0');
S1.IntegrationTime=5.0;

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in CloseComm.
function CloseComm_Callback(hObject, eventdata, handles)
% hObject    handle to CloseComm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global hDevice1 hDevice2
spectrometer('deactivate',hDevice1);
spectrometer('deactivate',hDevice2);
spectrometer('done');

function IntTimeEdt2_Callback(hObject, eventdata, handles)
% hObject    handle to IntTimeEdt2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of IntTimeEdt2 as text
%        str2double(get(hObject,'String')) returns contents of IntTimeEdt2 as a double
global S2
inttimestring=strrep(get(hObject,'String'),',','.');  %replace all decimal commas with points
set(hObject,'String',inttimestring)
S2.IntegrationTime=str2double(inttimestring);

% --- Executes during object creation, after setting all properties.
function IntTimeEdt2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IntTimeEdt2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
global S2
set(hObject,'String','5.0');
S2.IntegrationTime=5.0;
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function AverageEdt2_Callback(hObject, eventdata, handles)
% hObject    handle to AverageEdt2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of AverageEdt2 as text
%        str2double(get(hObject,'String')) returns contents of AverageEdt2 as a double
global S2
S2.NrAverages=str2num(get(hObject,'String'));

% --- Executes during object creation, after setting all properties.
function AverageEdt2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to AverageEdt2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
global S2
set(hObject,'String','1');
S2.NrAverages=1;
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


