// spectrometer.cpp : Defines the entry point for the DLL application.
//
#include "stdafx.h"
#include "spectrometer.h"
#include "avaspec.h"
#include "extcode.h"
#include <math.h>
#include <excpt.h>

#pragma warning(disable: 4996) // unsafe strcpy

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved )
{
    return TRUE;
}

#define IDLL_API extern "C" __declspec (dllexport)

// globals
AvsIdentityType Id[10];
MeasConfigType measconfig[10];
int devicehandles[10] = {0,0,0,0,0,0,0,0,0,0};
int numdevices = 0;
LVUserEventRef *LVHandle[10];

void DebugStringMessage(char * msg)
{
#ifdef _DEBUG
	DbgPrintf("AS5216 debug message: %s\n", msg);
#endif
}

void DebugIntegerMessage(int intval)
{
#ifdef _DEBUG
	DbgPrintf("AS5216 debug message: %d\n", intval);
#endif
}

void ErrorMessage(char * msg)
{
	DbgPrintf("AS5216 ERROR message: %s\n", msg);
}

int CheckRet(int retval)
{
	switch(retval)
	{
	case 0:
		//		return;  Do Nothing
		break;
	case -1:
		ErrorMessage("Invalid parameter");
		break;
	case -2:
		ErrorMessage("Operation not supported");
		break;
	case -3:
		ErrorMessage("Device not found");
		break;
	case -4:
		ErrorMessage("Invalid device ID");
		break;
	case -5:
		ErrorMessage("Operation pending");
		break;
	case -6:
		ErrorMessage("Timeout");
		break;
	case -7:
		ErrorMessage("Invalid password");
		break;
	case -8:
		ErrorMessage("Invalid measurement data");
		break;	
	case -9:
		ErrorMessage("Invalid size");
		break;
	case -10:
		ErrorMessage("Invalid pixel range");
		break;	
	case -11:
		ErrorMessage("Invalid integration time");
		break;	
	case -12:
		ErrorMessage("Invalid combination");
		break;	
	case -13:
		ErrorMessage("Invalid configuration");
		break;
	case -14:
		ErrorMessage("No measurement buffer available");
		break;
	case -15:
		ErrorMessage("Unknown error");
		break;
	case -16:
		ErrorMessage("Communication error");
		break;
	case -17:
		ErrorMessage("No spectra in RAM");
		break;
	case -18:
		ErrorMessage("Invalid DLL version");
		break;
	case -19:
		ErrorMessage("No memory");
		break;
	case -20:
		ErrorMessage("DLL initialisation failed");
		break;
	case -21:
		ErrorMessage("Invalid state");
		break;
	}
	return(retval);
}

// @1
IDLL_API short int __stdcall init( int a_handles[10],
                                   char a_serialnumbers[10*AVS_SERIAL_LEN],
                                   unsigned char status[10] )
{
    unsigned int l_Size=0;
	unsigned int l_RequiredSize=0;
	unsigned short numpix;
	bool error;

    DebugStringMessage("init");
	error=false;
	numdevices=AVS_Init(0);
    numdevices=AVS_GetNrOfDevices();
	memset(Id,0,sizeof(Id));  // clear all
	l_RequiredSize=numdevices*sizeof(AvsIdentityType);
    l_Size = l_RequiredSize;
	numdevices=AVS_GetList(l_Size,&l_RequiredSize,Id);
    strcpy(a_serialnumbers,"");
	memset(measconfig,0,sizeof(measconfig));  // clear all
	for (int i=0;i<numdevices;i++)
	{
		a_handles[i]=AVS_Activate(&Id[i]);
		if (a_handles[i]==1000)
		{
			ErrorMessage("Invalid handle acquired");
			error=true;
		}
		else
		{
			devicehandles[i]=a_handles[i];
		    strcat(a_serialnumbers,Id[i].SerialNumber);
		    status[i]=Id[i].Status;
			measconfig[i].m_StartPixel=0;    // set the minimal default values
            AVS_GetNumPixels(a_handles[i],&numpix);
            measconfig[i].m_StopPixel=numpix-1;    
            measconfig[i].m_IntegrationTime=5.0;
            measconfig[i].m_NrAverages=1;
		}
	}
	if (!error)
		return(numdevices);
	else
		return(-1);
}

// @2

IDLL_API short int __stdcall done( void )
{
	DebugStringMessage("done");
	int l_NrDevices=AVS_GetNrOfDevices();
	for (int i = 0; i < l_NrDevices; i++)
	{
		CheckRet(AVS_StopMeasure(devicehandles[i]));
		CheckRet(AVS_Deactivate(devicehandles[i]));
	}
	CheckRet(AVS_Done());
	return(0);
}

// @3

IDLL_API short int __stdcall getnumpix(	int hDevice,
	                                    unsigned short *numpix )
{
	DebugStringMessage("getnumpix");
	int ret=CheckRet(AVS_GetNumPixels(hDevice,numpix));
	return(ret);
}

// @4

IDLL_API short int __stdcall getlambda(	int hDevice,
	                                    pixelarray lambda )
{
	DebugStringMessage("getlambda");
	int ret=CheckRet(AVS_GetLambda(hDevice,lambda));
	return(ret);
}

// @5

IDLL_API short int __stdcall setintegrationtime( int hDevice,
	                                             float IntTime )
{
	int index,ret;
	DebugStringMessage("setintegrationtime");
	// find the index of the device in the devicehandles array
	index=-1;
	for (int i = 0; i < numdevices; i++)
	{
		if (hDevice==devicehandles[i])
		  index=i;
	}
	if (index!=-1)
	{
		measconfig[index].m_IntegrationTime=IntTime;
		// DbgPrintf("integration time: %f",measconfig[index].m_IntegrationTime);
		// DbgPrintf("averages        : %d",measconfig[index].m_NrAverages);
		ret=CheckRet(AVS_PrepareMeasure(hDevice,&measconfig[index]));
		return(ret);
	}
	else
		return(-1);
}

// @6

IDLL_API short int __stdcall setnumaverages( int hDevice,
	                                         unsigned int Averages )
{
	int index,ret;
	DebugStringMessage("setnumaverages");
	// find the index of the device in the devicehandles array
	index=-1;
	for (int i = 0; i < numdevices; i++)
	{
		if (hDevice==devicehandles[i])
		  index=i;
	}
	if (index!=-1)
	{
		measconfig[index].m_NrAverages=Averages;
		// DbgPrintf("integration time: %f",measconfig[index].m_IntegrationTime);
		// DbgPrintf("averages        : %d",measconfig[index].m_NrAverages);
		ret=CheckRet(AVS_PrepareMeasure(hDevice,&measconfig[index]));
		return(ret);
	}
	else
		return(-1);
}

// @7

IDLL_API short int __stdcall measure( int hDevice,
									  LVUserEventRef *msg )
{
	int index,ready,ret;
	DWORD timeout;

	DebugStringMessage("measure");
	// find the index of the device in the devicehandles array
	index=-1;
	for (int i = 0; i < numdevices; i++)
	{
		if (hDevice==devicehandles[i])
		  index=i;
	}
	if (index!=-1)
	{
		ret=CheckRet(AVS_UseHighResAdc(hDevice,true));
		ret=CheckRet(AVS_PrepareMeasure(hDevice,&measconfig[index]));
		ret=CheckRet(AVS_Measure(hDevice,0,1)); // single measurement

		ready=0;
		timeout=(DWORD) measconfig[index].m_IntegrationTime*(measconfig[index].m_NrAverages+1)+5000;
		// in milliseconds, 5 seconds over expected value
		// m_NrAverages+1 is a fix for the prescan mode of e.g. the 3648

		DWORD time1=GetTickCount();
		DWORD time2=GetTickCount();
		while ((!ready) && ((time2-time1)<timeout))
		{
			time2=GetTickCount();
			ready=CheckRet(AVS_PollScan(hDevice));
			Sleep(1);
			// test on time-out (integrationtime * averages)
			if ((time2-time1)>=timeout)
			{
				ret=-1;
				break;
			}
		}

		// Post event to Labview
		EVENT_SEND eventF;
		eventF.handle=hDevice;
		eventF.result=0;  // follow convention for Windows messages: <0:error, 0:OK, >0:storetoram

		PostLVUserEvent(*msg,(void *)&eventF );

		return(ret);
	}
	else
		return(-1);
}

// @8

IDLL_API short int __stdcall getdata( int hDevice,
									  unsigned int timelabel,
									  pixelarray data )
{
	int ret;
	DebugStringMessage("getdata");
	ret=CheckRet(AVS_GetScopeData(hDevice,&timelabel,data));
	return(ret);
}

// @9

IDLL_API short int __stdcall stopscan( int hDevice )
{
	int ret;
	DebugStringMessage("stopscan");
	ret=CheckRet(AVS_StopMeasure(hDevice));
	return(ret);
}

// @10

IDLL_API short int __stdcall setstartpixel( int hDevice,
	                                        unsigned short StartPixel )
{
	int index,ret;
	DebugStringMessage("setstartpixel");
	// find the index of the device in the devicehandles array
	index=-1;
	for (int i = 0; i < numdevices; i++)
	{
		if (hDevice==devicehandles[i])
		  index=i;
	}
	if (index!=-1)
	{
		measconfig[index].m_StartPixel=StartPixel;
		ret=CheckRet(AVS_PrepareMeasure(hDevice,&measconfig[index]));
		return(ret);
	}
	else
		return(-1);
}

// @11

IDLL_API short int __stdcall setstoppixel( int hDevice,
	                                       unsigned short StopPixel )
{
	int index,ret;
	DebugStringMessage("setstoppixel");
	// find the index of the device in the devicehandles array
	index=-1;
	for (int i = 0; i < numdevices; i++)
	{
		if (hDevice==devicehandles[i])
		  index=i;
	}
	if (index!=-1)
	{
		measconfig[index].m_StopPixel=StopPixel;
		ret=CheckRet(AVS_PrepareMeasure(hDevice,&measconfig[index]));
		return(ret);
	}
	else
		return(-1);
}

// @12

IDLL_API short int __stdcall setintegrationdelay( int hDevice,
	                                              int IntegrationDelay )
{
	int index,ret;
	DebugStringMessage("setintegrationdelay");
	// find the index of the device in the devicehandles array
	index=-1;
	for (int i = 0; i < numdevices; i++)
	{
		if (hDevice==devicehandles[i])
		  index=i;
	}
	if (index!=-1)
	{
		measconfig[index].m_IntegrationDelay=IntegrationDelay;
		ret=CheckRet(AVS_PrepareMeasure(hDevice,&measconfig[index]));
		return(ret);
	}
	else 
		return(-1);
}

// @13

IDLL_API short int __stdcall setcordyndark( int hDevice,
	                                        unsigned char CorDynDark )
{
	int index,ret;
	DebugStringMessage("setcordyndark");
	// find the index of the device in the devicehandles array
	index=-1;
	for (int i = 0; i < numdevices; i++)
	{
		if (hDevice==devicehandles[i])
		  index=i;
	}
	if (index!=-1)
	{
		measconfig[index].m_CorDynDark.m_Enable=CorDynDark;
		measconfig[index].m_CorDynDark.m_ForgetPercentage=100;
		ret=CheckRet(AVS_PrepareMeasure(hDevice,&measconfig[index]));
		return(ret);
	}
	else
		return(-1);
}

// @14

IDLL_API short int __stdcall setsmoothing( int hDevice,
	                                       unsigned short Smoothing )
{
	int index,ret;
	DebugStringMessage("setsmoothing");
	// find the index of the device in the devicehandles array
	index=-1;
	for (int i = 0; i < numdevices; i++)
	{
		if (hDevice==devicehandles[i])
		  index=i;
	}
	if (index!=-1)
	{
		measconfig[index].m_Smoothing.m_SmoothPix=Smoothing;
		measconfig[index].m_Smoothing.m_SmoothModel=0;
		ret=CheckRet(AVS_PrepareMeasure(hDevice,&measconfig[index]));
		return(ret);
	}
	else
		return(-1);
}

// @15

IDLL_API short int __stdcall settriggermode( int hDevice,
	                                         unsigned char TriggerMode )
{
	int index,ret;
	DebugStringMessage("settriggermode");
	// find the index of the device in the devicehandles array
	index=-1;
	for (int i = 0; i < numdevices; i++)
	{
		if (hDevice==devicehandles[i])
		  index=i;
	}
	if (index!=-1)
	{
		measconfig[index].m_Trigger.m_Mode=TriggerMode;
		ret=CheckRet(AVS_PrepareMeasure(hDevice,&measconfig[index]));
		return(ret);
	}
	else
		return(-1);
}

// @16

IDLL_API short int __stdcall settriggersource( int hDevice,
	                                           unsigned char TriggerSource )
{
	int index,ret;
	DebugStringMessage("settriggersource");
	// find the index of the device in the devicehandles array
	index=-1;
	for (int i = 0; i < numdevices; i++)
	{
		if (hDevice==devicehandles[i])
		  index=i;
	}
	if (index!=-1)
	{
		measconfig[index].m_Trigger.m_Source=TriggerSource;
		ret=CheckRet(AVS_PrepareMeasure(hDevice,&measconfig[index]));
		return(ret);
	}
	else
		return(-1);
}

// @17

IDLL_API short int __stdcall settriggersourcetype( int hDevice,
	                                               unsigned char TriggerSourceType )
{
	int index,ret;
	DebugStringMessage("settriggersourcetype");
	// find the index of the device in the devicehandles array
	index=-1;
	for (int i = 0; i < numdevices; i++)
	{
		if (hDevice==devicehandles[i])
		  index=i;
	}
	if (index!=-1)
	{
		measconfig[index].m_Trigger.m_SourceType=TriggerSourceType;
		ret=CheckRet(AVS_PrepareMeasure(hDevice,&measconfig[index]));
		return(ret);
	}
	else
		return(-1);
}

// @18

IDLL_API short int __stdcall setsaturationdetection( int hDevice,
	                                                 unsigned char SaturationDetection )
{
	int index,ret;
	DebugStringMessage("setsaturationdetection");
	// find the index of the device in the devicehandles array
	index=-1;
	for (int i = 0; i < numdevices; i++)
	{
		if (hDevice==devicehandles[i])
		  index=i;
	}
	if (index!=-1)
	{
		measconfig[index].m_SaturationDetection=SaturationDetection;
		ret=CheckRet(AVS_PrepareMeasure(hDevice,&measconfig[index]));
		return(ret);
	}
	else
		return(-1);
}

// @19

IDLL_API short int __stdcall setnrstoretoram( int hDevice,
	                                          unsigned short NrStoreToRam )
{
	int index,ret;
	DebugStringMessage("setnrstoretoram");
	// find the index of the device in the devicehandles array
	index=-1;
	for (int i = 0; i < numdevices; i++)
	{
		if (hDevice==devicehandles[i])
		  index=i;
	}
	if (index!=-1)
	{
		measconfig[index].m_Control.m_StoreToRam=NrStoreToRam;
		ret=CheckRet(AVS_PrepareMeasure(hDevice,&measconfig[index]));
		return(ret);
	}
	else
		return(-1);
}

// @20

IDLL_API short int __stdcall setsyncmode( int hDevice,
	                                      unsigned char SyncMode )
{
	int ret;
	DebugStringMessage("setsyncmode");
	ret=CheckRet(AVS_SetSyncMode(hDevice,SyncMode));
	return(ret);
}

// @21

IDLL_API short int __stdcall deactivate( int hDevice )
{
	int ret,index;
	DebugStringMessage("deactivate");
	ret=CheckRet(AVS_Deactivate(hDevice));
	index=-1;
	for (int i = 0; i < numdevices; i++)
	{
		if (hDevice==devicehandles[i])
		  index=i;
	}
	if (index!=-1)
	{
		devicehandles[index]=0;  // reset devicehandle
		return(ret);
	}
	else
		return(-1);
}

// @22

IDLL_API short int __stdcall activate( char a_serialnumber[AVS_SERIAL_LEN],
									   int *a_handle )
{
	int ret,index;
	DebugStringMessage("activate");
	index=-1;
	for (int i = 0; i < numdevices; i++)
	{
		if (strcmp(a_serialnumber,Id[i].SerialNumber)==0)
		  index=i;
	}
	if (index!=-1)
	{
		if (devicehandles[index]==0) // only when not already activated
		{
			ret=CheckRet(AVS_Activate(&Id[index]));
			devicehandles[index]=ret;
			return(ret);
		}
		return(-2);
	}
	else
		return(-1);
}

// @23

IDLL_API short int __stdcall getsaturated( int hDevice,
                                           saturatedarray satdata )
{
	int ret;
	DebugStringMessage("getsaturated");
	ret=CheckRet(AVS_GetSaturatedPixels(hDevice,satdata));
	return(ret);
}