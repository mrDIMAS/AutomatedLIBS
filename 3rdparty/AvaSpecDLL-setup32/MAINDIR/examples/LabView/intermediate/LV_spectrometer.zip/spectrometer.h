#ifndef SPECTROMETER_H
#define SPECTROMETER_H

//----------------------------------------------------------------------------
// Import overview
//----------------------------------------------------------------------------
#define DLL_EXPORTS

#ifdef DLL_EXPORTS
#define IDLL_API extern "C" __declspec (dllexport)
#else
#define IDLL_API extern "C" __declspec (dllimport)
#endif

#pragma pack(push,1) 

#include "avaspec.h"

typedef double pixelarray[4096];
typedef unsigned char saturatedarray[4096];

IDLL_API short int __stdcall init( int a_handles[10],
	                               char a_serialnumbers[10*AVS_SERIAL_LEN],
	                               unsigned char status[10] );

IDLL_API short int __stdcall done( void );

IDLL_API short int __stdcall getnumpix( int hDevice,
	                                    unsigned short *numpix );

IDLL_API short int __stdcall getlambda(	int hDevice,
	                                    pixelarray lambda );

IDLL_API short int __stdcall setintegrationtime( int hDevice,
	                                             float IntTime );

IDLL_API short int __stdcall setnumaverages( int hDevice,
	                                         unsigned int Averages );

IDLL_API short int __stdcall measure( int hDevice,
	                                  LVUserEventRef *msg );

IDLL_API short int __stdcall getdata( int hDevice,
	                                  unsigned int timelabel,
	                                  pixelarray data );

IDLL_API short int __stdcall stopscan( int hDevice );

IDLL_API short int __stdcall setstartpixel( int hDevice,
	                                        unsigned short StartPixel );

IDLL_API short int __stdcall setstoppixel( int hDevice,
	                                       unsigned short StopPixel );

IDLL_API short int __stdcall setintegrationdelay( int hDevice,
	                                              int IntegrationDelay );

IDLL_API short int __stdcall setcordyndark( int hDevice,
	                                        unsigned char CorDynDark );

IDLL_API short int __stdcall setsmoothing( int hDevice,
	                                       unsigned short Smoothing );

IDLL_API short int __stdcall settriggermode( int hDevice,
	                                         unsigned char TriggerMode );

IDLL_API short int __stdcall settriggersource( int hDevice,
	                                           unsigned char TriggerSource );

IDLL_API short int __stdcall settriggersourcetype( int hDevice,
	                                               unsigned char TriggerSourceType );

IDLL_API short int __stdcall setsaturationdetection( int hDevice,
	                                                 unsigned char SaturationDetection );

IDLL_API short int __stdcall setnrstoretoram( int hDevice,
	                                          unsigned short NrStoreToRam );

IDLL_API short int __stdcall setsyncmode( int hDevice,
	                                      unsigned char SyncMode );

IDLL_API short int __stdcall deactivate( int hDevice );

IDLL_API short int __stdcall activate( char a_serialnumber[AVS_SERIAL_LEN],
									   int *a_handle );

IDLL_API short int __stdcall getsaturated( int hDevice,
                                           saturatedarray satdata );

//----------------------------------------------------------------------------
// End of definitions
//----------------------------------------------------------------------------
#pragma pack(pop) 

#endif  // SPECTROMETER_H


